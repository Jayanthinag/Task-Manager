const apiURL = 'http://localhost:3000/api';

new Vue({
    el: '#app',
    data: {
        isAuthenticated: false,
        newTask: '',
        tasks: [],
        showLogin: false,
        showRegister: false,
        loginEmail: '',
        loginPassword: '',
        registerEmail: '',
        registerPassword: '',
        token: ''
    },
    methods: {
        async fetchTasks() {
            const response = await fetch(`${apiURL}/tasks`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });
            const data = await response.json();
            this.tasks = data;
        },
        async addTask() {
            if (this.newTask.trim() !== '') {
                const response = await fetch(`${apiURL}/tasks`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${this.token}`
                    },
                    body: JSON.stringify({ text: this.newTask })
                });
                const task = await response.json();
                this.tasks.push(task);
                this.newTask = '';
            }
        },
        async updateTask(task) {
            await fetch(`${apiURL}/tasks/${task._id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify(task)
            });
        },
        async removeTask(id) {
            await fetch(`${apiURL}/tasks/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${this.token}` }
            });
            this.tasks = this.tasks.filter(task => task._id !== id);
        },
        async login() {
            const response = await fetch(`${apiURL}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: this.loginEmail,
                    password: this.loginPassword
                })
            });
            const data = await response.json();
            if (data.token) {
                this.token = data.token;
                this.isAuthenticated = true;
                this.fetchTasks();
                this.showLogin = false;
            }
        },
        async register() {
            const response = await fetch(`${apiURL}/auth/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: this.registerEmail,
                    password: this.registerPassword
                })
            });
            const data = await response.json();
            if (data.token) {
                this.token = data.token;
                this.isAuthenticated = true;
                this.fetchTasks();
                this.showRegister = false;
            }
        },
        logout() {
            this.isAuthenticated = false;
            this.token = '';
            this.tasks = [];
        }
    }
});
